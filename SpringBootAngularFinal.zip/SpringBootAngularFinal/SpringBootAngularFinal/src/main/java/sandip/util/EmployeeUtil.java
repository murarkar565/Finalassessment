package sandip.util;

import org.springframework.stereotype.Component;

import sandip.model.Employee;

@Component
public class EmployeeUtil {

	public void mapToActualObject(Employee actual, Employee employee) {
		if(employee.getName()!=null)
			actual.setName(employee.getName());
		actual.setSalary(employee.getSalary());
	
		if(employee.getDesig()!=null)
			actual.setDesig(employee.getDesig());
		actual.setAddress(employee.getAddress());
		
	}

}
