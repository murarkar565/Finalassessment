package sandip.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import sandip.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>
{

}
