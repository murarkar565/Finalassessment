package sandip.service;

import java.util.List;
import java.util.Optional;

import sandip.model.Employee;

public interface IEmployeeService {

	Integer saveEmployee(Employee e);
	void updateEmployee(Employee e);
	
	void deleteEmployee(Integer empno);

	Optional<Employee> getOneEmployee(Integer empno);
	List<Employee> getAllEmployee();

	boolean isEmployeeExist(Integer empno);
}
